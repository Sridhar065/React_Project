import React from 'react'
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom'; 
import './App.css';
// import { Button, Form, Input, InputGroup, Row } from 'reactstrap';

export default class Login extends React.Component {
    constructor() {
        super();
        this.state = {
            email: '',
            password: ''
        }

    }
    // email(event) {
    //     this.setState({ email: event.target.value })
    // }
    // password(event) {
    //     this.setState({ password: event.target.value })
    // }

    handleChange(event) {
        var value = event.target.name;
        this.setState({
          [value]: event.target.value
        });
      }

    async login(event) {
        console.log(this.state)
        await fetch('http://localhost:8092/api/v1/employee/get-login_in', {
                method: 'post',
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(this.state)
            }).then((Response) => Response.json())
                .then((result) => {
                    console.log(result);
                   
                    if (result.status == 200)
                    {
                         window.location = "/welcomePage"
                        }
                    else {
                        alert('Invalid User');
                    }
                })
        }
        
        render() {
            return (
            <div id="login" style={{background: "linear-gradient(115deg, #56d8e4 10%, #9f01ea 90%)", width:"100%", height:"88.2vh"}}>
            <div className="center">
                    <input type="checkbox" id="show" />
                    <label for="show" className="show-btn">View Form</label>
                    <div className="container">
                    <label for="show" className="close-btn fas fa-times" title="close"></label>
                    <div className="text">
                        Login Form
                    </div>
                <form action="#">
                    <div className="data">
                    <label>Email</label>
                    <input type="text" name="email" placeholder="Enter Email" value={this.state.email} onChange={this.handleChange.bind(this)} required />
                </div>
                <div className="data">
                    <label>Password</label>
                    <input type="password" name="password" placeholder="Enter Password" value={this.state.password} onChange={this.handleChange.bind(this)} required />
                </div>
                <div className="forgot-pass">
                <a href="#">Forgot Password?</a></div>
                <div className="btn">
                    <div className="inner">
                </div>
                    <button onClick={this.login.bind(this)} color="success" block>login</button>
                </div>
                <div className="signup-link">
                    Not a member? <a href="#">Signup now</a></div>
                </form>
                </div>
                </div>
            </div>

            );
        }
    }


    // import React, {useState} from 'react';
    // import { withRouter } from "react-router-dom";
    // import axios from 'axios';
    
    // function Login(props) {
    //     const [state , setState] = useState({
    //         email : "",
    //         password : "",
    //         successMessage: null
    //     })
    //     const handleChange = (e) => {
    //         const {id , value} = e.target   
    //         setState(prevState => ({
    //             ...prevState,
    //             [id] : value
    //         }))
    //     }
    
    //     const handleSubmitClick = (e) => {
    //         e.preventDefault();
    //         const payload={
    //             "email":state.email,
    //             "password":state.password,
    //         }
    //         axios.get('http://localhost:8092/api/v1/employee/get-login_in')
          
    //             .then(function (response) {
    //                 if(response.status === 200){
    //                     setState(prevState => ({
    //                         ...prevState,
    //                         'successMessage' : 'Login successful. Redirecting to home page..'
    //                     }))
                      
    //                 }
    //                 else if(response.code === 204){
    //                     props.showError("Username and password do not match");
    //                 }
    //                 else{
    //                     props.showError("Username does not exists");
    //                 }
    //             })
    //             .catch(function (error) {
    //                 console.log(error);
    //             });
    //     }
        
    //     const redirectToRegister = () => {
    //         window.location = "/welcomePage";
    //         props.updateTitle('welcomePage');
    //     }
    //     return(
    //         <div className="card col-12 col-lg-4 login-card mt-2 hv-center">
    //             <form>
    //                 <div className="form-group text-left">
    //                 <label htmlFor="exampleInputEmail1">Email address</label>
    //                 <input type="email" 
    //                        className="form-control" 
    //                        id="email" 
    //                        aria-describedby="emailHelp" 
    //                        placeholder="Enter email" 
    //                        value={state.email}
    //                        onChange={handleChange}
    //                 />
    //                 <small id="emailHelp" className="form-text text-muted">We'll never share your email with anyone else.</small>
    //                 </div>
    //                 <div className="form-group text-left">
    //                 <label htmlFor="exampleInputPassword1">Password</label>
    //                 <input type="password" 
    //                        className="form-control" 
    //                        id="password" 
    //                        placeholder="Password"
    //                        value={state.password}
    //                        onChange={handleChange} 
    //                 />
    //                 </div>
    //                 <div className="form-check">
    //                 </div>
    //                 <button 
    //                     type="submit" 
    //                     className="btn btn-primary"
    //                     onClick={handleSubmitClick}
    //                 >Submit</button>
    //             </form>
    //             <div className="alert alert-success mt-2" style={{display: state.successMessage ? 'block' : 'none' }} role="alert">
    //                 {state.successMessage}
    //             </div>
    //             <div className="registerMessage">
    //                 <span>Dont have an account? </span>
    //                 <span className="loginText" onClick={() => redirectToRegister()}>Register</span> 
    //             </div>
    //         </div>
    //     )
    // }
    
    // export default Login;